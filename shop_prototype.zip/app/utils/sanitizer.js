const dangerousKeys = [
    'constructor',
    'prototype',
    'toString',
    'valueOf',
    'hasOwnProperty',
    'isPrototypeOf',
    '__defineGetter__',
    '__defineSetter__',
    '__lookupGetter__',
    '__lookupSetter__',
    'propertyIsEnumerable',
    'statusCode',
    'status',
    'send',
    'end',
    'write',
    'headers',
    'setHeader',
    'getHeader',
    'auth',
    'authenticated',
    'loggedIn',
    'userId',
    'role',
    'privilege',
    'flags',
    'config',
    'settings',
    'eval',
    'watch',
    'unwatch',
    'env',
    'debug',
    'log',
    'logger',
    'locals',
    'method',
    'url',
    'path',
    'app',
    'next'
];

function sanitize(obj, visited = new WeakSet()) {
    if (typeof obj !== 'object' || obj === null) return obj;
    
    if (visited.has(obj)) return {};
    
    visited.add(obj);
    
    if (Array.isArray(obj)) {
        const cleanArray = [];
        for (let i = 0; i < obj.length; i++) {
            cleanArray[i] = sanitize(obj[i], visited);
        }
        return cleanArray;
    }
    
    const cleanObj = {};
    
    for (const key in obj) {
        if (!obj.hasOwnProperty(key)) continue;
        
        if (dangerousKeys.includes(key)) {
            continue;
        }
        
        try {
            cleanObj[key] = sanitize(obj[key], visited);
        } catch (error) {
            console.warn(`Warning: Skipping property '${key}' due to error:`, error.message);
        }
    }
    
    return cleanObj;
}

module.exports = { sanitize };